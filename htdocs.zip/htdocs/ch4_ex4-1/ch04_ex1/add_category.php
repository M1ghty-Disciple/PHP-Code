<?php
//get the name of the category from the form on the category list file
    $categoryName = filter_input(INPUT_POST,"categoryName");

    //validate the input
    if($categoryName == null){
        $error = "Invalid product data. Check all fields and try again.";
        include('error.php');
    }else{
        require_once('database.php');
    }

    //Add the category to the database
    $query = 'INSERT INTO category
                (categoryName)
            VALUES
                (:categoryName)';
    $statement = $db->prepare($query);
    $statement->bindValue(':categoryName', $categoryName);
    $statement->execute();
    $statement->closeCursor();

    //display the category table
    include('category_list');












?>