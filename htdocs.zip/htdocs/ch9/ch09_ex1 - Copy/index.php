<?php
//set default values
$name = '';
$email = '';
$phone = '';
$message = 'Enter some data and click on the Submit button.';

//process
$action = filter_input(INPUT_POST, 'action');

switch ($action) {
    case 'process_data':
        $name = filter_input(INPUT_POST, 'name');
        $email = filter_input(INPUT_POST, 'email');
        $phone = filter_input(INPUT_POST, 'phone');

        /*************************************************
         * validate and process the name
         ************************************************/
        // 1. make sure the user enters a name
        if($name == ''){
            $message = "Please enter a valid name.";
            $validName = false;
        }
        // 2. display the name with only the first letter capitalized
        else{
            $nameArray = explode(' ', $name);//breaks the name field into a an array to separate first last and middle name

            //this block assigns parts name to their respctive variable
            $first = '';
            $middle = '';
            $last = '';
            if(count($nameArray) > 2){
                $first = ucfirst($nameArray[0]);
                $middle = ucfirst($nameArray[1]);
                $last = ucfirst($nameArray[2]);
            }else{
                $first = ucfirst($nameArray[0]);
                $last = ucfirst($nameArray[1]);
            
        }
        $validName = true;
    }
        
        
        /*************************************************
         * validate and process the email address
         ************************************************/
        
         // 1. make sure the user enters an email
        if($email == ''){
            $message = "Please enter an email address";
        }else{
            // 2. make sure the email address has at least one @ sign and one dot character
         
            //using the strpos function to check whether these are in the input
            $i = strpos($email, '.');
            $j = strpos($email, '@');
         
            if($i === false || $j === false){
                $message = "Please enter a valid email address.";
                $validEmail = false;
            }else{
                $validEmail = true;
            }
        }
        
         
        
        
        
        /*************************************************
         * validate and process the phone number
         ************************************************/
        // 1. make sure the user enters at least seven digits, not including formatting characters
        if(strlen($phone) == 10){
           $areaCode = substr($phone, 0, 3);
           $part1 = substr($phone, 3, 3);
           $part2 = substr($phone, 6);
           $phoneF = '('. $areaCode . ')' . $part1 . '-' . $part2;
           $validPhone = true;
       
        // 2. format the phone number like this 123-4567 or this 123-456-7890
        }else if(strlen($phone) == 7){
            $part1 = substr($phone, 0, 3);
            $part2 = substr($phone, 3, 6);
            $phoneF = $part1 . '-' . $part2;
            $validPhone =true;
        }else{
            $message = "Please enter a valid phone number";
            $validPhone = false;
        }
        
        /*************************************************
         * Display the validation message
         ************************************************/
        if($validName && $validEmail && $validPhone){
            printf("Hello %s, <br><br>
            Thank you for entering this data: <br><br>
            Name: %s<br>
            Email: %s<br>
            Phone: %s",$first,$name,$email,$phoneF);
            $message = 'Thank you have a great day. <3';
        }

        break;
}
include 'string_tester.php';
?>