<?php
//The variables that hold the data from the form
$hours = filter_input(INPUT_POST, "hour", FILTER_VALIDATE_INT);
$wage = filter_input(INPUT_POST, "wage", FILTER_VALIDATE_FLOAT);

//A varible that will store error message for the user
$error = "";


//if - else block to handle errors
if(!isset($hours)){
    $error = "**Must enter a value in the Hours Worked text field";

}else if($hours < 1){
    $error = "**Hours Worked must be greater than 0";

}else if(!isset($wage)){
    $error = "**Must enter a number in the Hourly Wage text field";

}else if($wage < 1){
    $error = "**Hourly Wage must be greater than 0";

}else if($wage === false){
    $error = "**Hourly wage must be a number";
}

else{
    $error = "";
}

//if an error occurs
if($error != ""){
    include ("incomeCalculator.php");
    }
//calculate and format the gross income
$grossIncome = " $". number_format($hours*$wage,2);
 



?>


<!DOCTYPE html>
<html>
    <head>
        <title>Calculated Results</title>
        <link rel="stylesheet" href="incomeCalculator.css">
    </head>
    <body>
        <h1>Gross Pay:<?php echo $grossIncome;?></h1>
        
    </body>
</html>