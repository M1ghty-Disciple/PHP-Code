<?php 
    //resets the variable when brought to this page
    if(!isset($hours)){$hours = 0;}
    if(!isset($wage)){$wage = 0;}


?>



<!DOCTYPE html>
<html>
    <head>
        <title>Gross Income Calculator</title>
        <link rel="stylesheet" href="incomeCalculator.css">
    </head>

    <body>
        <h1>Income Calculator</h1>
        <form action="incomeResult.php" method="post">
            <label for="hour">Hours Worked:</label>
            <input type="number" name="hour"><br>
            <br>
            <label for="wage">Hourly Wage:</label>
            <input type="text" name="wage"><br>

            <button type="submit" name="submit">Calculate</button><br>
            <button type="reset" name="clear">Clear</button>
            <P name="error"><?php if(isset($error)){echo $error;}?></P>
            

        </form>
    </body>
</html>
