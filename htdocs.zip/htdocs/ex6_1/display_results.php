
<?php

$error_message = '';

//get the data from the form
$investment = filter_input(INPUT_POST, 'investment', FILTER_VALIDATE_FLOAT);
$interestRate = filter_input(INPUT_POST, 'interest_rate', FILTER_VALIDATE_FLOAT);
$years = filter_input(INPUT_POST, 'years',FILTER_VALIDATE_INT);

//validate investment
if($investment === false){
    $error_message = 'Investment must be a valid number.';
}else if($investment <= 0){
    $error_message = 'Investment must be greater than zero';

 //validate insterest rate    
}else if($interestRate === false){
    $error_message = 'Interest rate must be a valid number.';
    
}else if($interestRate <= 0){
    $error_message = 'Interest rate must be greater than 0';
}//validate years
else if($years === false){
    $error_message = 'Years must be a valid whole number.';
    
}else if($years <= 0){$error_message = 'Years must be greater than 0';}
else if ($years > 30){$error_message = 'Years must be lass than 31';}

else{$error_message = '';}

//if an error is detected go to the index page
if($error_message != ''){
    include('index.php');
    exit();
}

$future_value = $investment;
//Using echo statements to trace the execution
echo 'future value = ', $future_value, '<br>';
echo 'interest rate = ', $interestRate, '<br>';
echo 'years = ', $years, '<br>';
echo 'This is the start of the for loop', '<br>';

//calculate the futer value
for($i = 1; $i <= $years; $i++){
    $future_value += $future_value * $interestRate*0.01;
    echo 'i = ', $i, '<br>';
    echo 'future_value: ', $future_value, '<br>';
}

//apply currency and percent formatting
$investment_f = '$'.number_format($investment,2);
$yearly_rate_f = $interestRate.'%';
$future_value_f = '$'.number_format($future_value,2);

?>

<!doctype html>
<html>
    <head>
        <title>Future Value Calculator</title>
        <link rel ="stylesheet" type="text/css" href="main.css">
    </head>
    <body>
        <main>
            <h1>Future Value Calculation</h1>
            <label>Investment Amount:</label>
            <span><?php echo $investment_f;?></span><br>
            
            <label>Yearly Interest Rate:</label>
            <span><?php echo $yearly_rate_f;?></span><br>
            
            <label>Number of Years:</label>
            <span> <?php echo $years;?> </span><br>
            
            <label>Future Value:</label>
            <span><?php echo $future_value_f;?></span>
        </main>
    </body>
</html>