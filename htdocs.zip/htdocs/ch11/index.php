<?php 
$task_list = filter_input(INPUT_POST, 'tasklist', FILTER_DEFAULT, FILTER_REQUIRE_ARRAY);
if($task_list ===NULL){
    $task_list = array();
}

$action = filter_input(INPUT_POST, 'action');

$errors = array();

switch($action){
    case 'add':
        $new_task = filter_input(INPUT_POST, 'task');
        if(empty($new_task)){
            $errors[] = 'The new task cannot be empty.';
        }else{
            array_push($task_list, $new_task);

            //creating a for loop to reorder the array so that the new task is on top
            for($i = 0; $i < count($task_list); $i++){
                $temp = $task_list[$i];
                $task_list[$i] = $task_list[(count($task_list)-1)];
                $task_list[(count($task_list)-1)] = $temp;

            }
        }
        break;
    
    case 'remove':
        unset($task_list[0]);
        $task_list = array_values($task_list);

        break;




    case 'delete':
        $task_index = filter_input(INPUT_POST, 'taskid', FILTER_VALIDATE_INT);
        if($task_index === NULL || $task_index === false){
            $errors[] = 'The task cannot be deleted.'; 
        }else{
            unset($task_list[$task_index]);
            $task_list = array_values($task_list);

            
        }

        break;
    
    case "sort":
        sort($task_list);
        break;
    
    case "modify":
        $task_index = filter_input(INPUT_POST, 'taskid', FILTER_VALIDATE_INT);
        $task = filter_input( INPUT_POST, 'task');
        if($task_index === NULL || $task_index === false){
            $errors[] = 'The task cannot be modified.'; 
        }elseif($task === NULL){
            $errors[] = 'Not a valid task';
        }else{
            $task_list[$task_index] = $task;
        }
       
        break;

    case "promote":
        $task_index = filter_input(INPUT_POST, 'taskid', FILTER_VALIDATE_INT);
        if($task_index === NULL || $task_index === false || $task_index == 0){
            $errors[] = 'The task cannot be promoted.'; 
        }else{
            $newSpot = $task_index - 1;
            $temp = $task_list[$newSpot];
            $task_list[$newSpot] = $task_list[$task_index];
            $task_list[$task_index] = $temp;


        }
        
        break;
}






include('task_list.php');
?>