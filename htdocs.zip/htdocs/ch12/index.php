<?php  
//start session management
session_start();

//create cart array if needed
if(empty($_SESSION['cart13'])){$_SESSION['cart13'] = array();}

$cart = $_SESSION['cart13'];
//create table of products
$products = array();
$products['MMS-1754'] = array('name' => 'Flute', 'cost' => '149.50');
$products['MMS-6289'] = array('name' => 'Trumpet', 'cost' => '199.50');
$products['MMS-3408'] = array('name' => 'Clarinet', 'cost' => '299.50');

//include the cart function
require_once('cart.php');

//get the sort key
$sort_key = filter_input(INPUT_POST, 'sortkey');
if($sort_key === NULL){$sort_key = 'name';}

//get the action to perform 
$action = filter_input(INPUT_POST, 'action');
if($action === NULL){
    $action = filter_input(INPUT_GET, 'action');
    if($action === NULL){
        $action = 'show_add_item';
    }
}

//add or update cart as needed
switch($action){

    case 'add':
        $key = filter_input(INPUT_POST, 'productkey');
        $quantity = filter_input(INPUT_POST, 'itempty');
        cart\add_item($cart, $key, $quantity);
        include('cart_view.php');
        
        
        break;

    case 'update':
        $new_quantity_list = filter_input(INPUT_POST, 'newqty', FILTER_DEFAULT, FILTER_REQUIRE_ARRAY);

        foreach($new_quantity_list as $key => $qty){
            if($_SESSION['cart13'][$key]['qty'] != $qty){
                cart\update_item($products, $key, $qty);
            }
        }
        cart\sort($sort_key);
        include('cart_view.php');
        break;
    
    case 'show_cart':
        include('cart_view.php');
        break;
    
    case 'show_add_item':
        include('cart_view.php');
        break;
    
    

    case 'empty_cart':
        unset($_SESSION['cart13']);
        include('cart_view.php');
        break;

}




?>