<?php 
namespace cart{
    //add item to the cart
    function add_item(&$cart, $name, $cost, $quantity){
        //same code as cart application for chapter 12
        $total = $cost * $quantity;
        $item = array(
            'name' => $name,
            'cost' => $cost,
            'quantity' => $total,
            'total' => $total
        );
        $cart = $item;
    }

    //update an item in the cart
    function update_item(&$cart, $key, $quantity){
        //same code as cart application for chapter 12
        if(isset($cart[$key])){
            if ($quantity <= 0){
                unset($cart[$key]);
            }
            else{
                $cart[$key]['qty'] = $quantity;
                $total = $cart[$key]['cost'] * $cart[$key]['qty'];
                $cart[$key]['$total'] = $total;
            }
        }
    }
    //get cart subtotal
    function get_subtotal($cart){
        //same code as cart application for chapter 12
        $subtotal = 0;
        foreach($cart as $item) {
            $subtotal += $item['total'];
        }
        $subtotal = round($subtotal, 2);
        $subtotal = number_format($subtotal,2);
        return;
    }

    //get a function for sorting the cart on the specified key
    function compare_factory($sort_key){
        return function($left, $right) use ($sort_key){
            if($left[$sort_key] == $right[$sort_key]){
                return 0;
            }else if($left[$sort_key] < $right[$sort_key]){
                return -1;
            }else{
                return 1;
            }
            
        };
    }

    //sort the cart on the specified key
    function sort($sort_key){
        $compare_function = compare_factory($sort_key);
        uasort($_SESSION['cart13'], $compare_function);
    }

}



?>