<?php 

//get the data from the form
$investment = filter_input(INPUT_POST, 'investment', FILTER_VALIDATE_FLOAT);
$interest_rate = filter_input(INPUT_POST,'interest_rate', FILTER_VALIDATE_FLOAT);
$years = filter_input(INPUT_POST, 'years', FILTER_VALIDATE_INT);
$error_message = '';
$date = date('m/d/Y');

//handle the error handling
function validInvestment($value){
    if($value === FALSE){
        throw new Exception('Investment must be a valid number');
    
    }else if($value <= 0){
        throw new Exception('Investment must be greater than 0');
    
    }
}
function validInterest($value){
    if($value === FALSE){
        throw new Exception('Interest must be a valid number');
    
    }else if($value <= 0){
        throw new Exception('Interest must be greater than 0');
    
    }else if($value > 15){
        throw new Exception('The interest rate must be less than or equal 15');
    }
}
function validYear($year){
    if($year === FALSE){
        throw new Exception('Year must be a valid number');
    
    }else if($year <= 0){
        throw new Exception('Year must be greater than 0');
    
    }else if($year > 30){
        throw new Exception('Year must be less than 30');
    }
}

try{
    validInvestment($investment);
    validInterest($interest_rate);
    validYear($years);
    

}catch(Exception $e){
    $error_message = $e->getMessage();

}

//incase an error message exists
if ($error_message != ''){
    include('index.php');
    exit();
}

//calcilate the future value
$future_value = $investment;
for($i = 1; $i <= $years; $i++){
    $future_value += $future_value * $interest_rate * 0.01;
}

//apply currencty and percent formating
$investment_f = '$'.number_format($investment, 2);
$yearly_rate_f = $interest_rate.'%';
$future_value_f = '$'.number_format($future_value, 2);



include('index.php');

?>

<!doctype html>
<html>
    <head>
        <title>Future Value Calculator</title>
    </head>
    <body>
        <main>
            <h1>Future Value Calculator</h1>

            <label>Investment Amount:</label>
            <span><?php echo htmlspecialchars($investment_f); ?></span><br>

            <label>Yearly Interest Rate:</label>
            <span><?php echo htmlspecialchars($yearly_rate_f); ?></span><br>

            <label>Number of Years:</label>
            <span><?php echo htmlspecialchars($years); ?></span><br>

            <label>Future Value:</label>
            <span><?php echo htmlspecialchars($future_value_f); ?></span><br>

            <p>This calculation was done on <?php echo $date; ?></p>
        </main>
    </body>
</html>