<?php
    // get the data from the form
    $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
    
    // get the rest of the data for the form
    $pwd = filter_input(INPUT_POST, 'password');
    $phone = filter_input(INPUT_POST, 'phone');
    $contact = filter_input(INPUT_POST, "contact_via");
    
    // for the heard_from radio buttons,
    $radioBtn = filter_input(INPUT_POST,'heard_from');
    if($radioBtn == "Search Engine"){
        $heardFrom = "Search Engine";
    
    }else if($radioBtn == "Friend"){
        $heardFrom = "Word of Mouth";
    
    }else if($radioBtn == "Other"){
        $heardFrom = "Other";
    // display a value of 'Unknown' if the user doesn't select a radio button
    }else{
        $heardFrom = "Unknown";
    }
    
    // for the wants_updates check box,
    $update = filter_input(INPUT_POST, 'wants_updates');
    if(isset($update)){$yes = true;}
    else{$yes = false;}
    // display a value of 'Yes' or 'No'
    if($yes){
        $message = "Yes";
    }else{
        $message = "No";
    }


    //comments
    $comment = filter_input(INPUT_POST, "comments");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Account Information</title>
    <link rel="stylesheet" type="text/css" href="main.css"/>
</head>
<body>
    <main>
        <h1>Account Information</h1>

        <label>Email Address:</label>
        <span><?php echo htmlspecialchars($email); ?></span><br>

        <label>Password:</label>
        <span><?php echo htmlspecialchars($pwd); ?></span><br>

        <label>Phone Number:</label>
        <span><?php echo htmlspecialchars($phone); ?></span><br>

        <label>Heard From:</label>
        <span><?php echo htmlspecialchars($heardFrom); ?></span><br>

        <label>Send Updates:</label>
        <span><?php echo htmlspecialchars($message); ?></span><br>

        <label>Contact Via:</label>
        <span><?php echo htmlspecialchars($contact); ?></span><br><br>

        <span>Comments:</span><br>
        <span><?php echo nl2br(htmlspecialchars($comment)); ?></span><br>        
    </main>
</body>
</html>