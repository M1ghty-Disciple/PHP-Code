<?php
    $statesArray = array('AL', 'AK', 'AZ', 'AR', 'CA', 'CO', 'CT', 'DE', 'FL', 'GA', 'HI', 'ID',
                'IL', 'IN', 'IA', 'KS', 'KY', 'LA', 'ME', 'MD', 'MA', 'MI', 'MN', 'MS', 'MO',
                'MT', 'NE', 'NV', 'NH', 'NJ', 'NM', 'NY', 'NC', 'ND', 'OH', 'OK', 'OR', 'PA',
                'RI', 'SC', 'SD', 'TN', 'TX', 'UT', 'VT', 'VA', 'WA', 'WV', 'WI', 'WY');

?>




<!DOCTYPE html>
<html>
    <head>
        <title>Student Registration Form</title>
    </head>
    <body>
        <main>
            <h1>Membership Application</h1>
            <p>To apply for memebership please complete all question</p>

            <form action="form_handler.php" method="post">
                <h2>Name</h2>
                
                <input type="text" name = 'first' placeholder="John"><br>
                <label>First Name</label>
                <br><br>
                <input type="text" name='last' placeholder="Smith"><br>
                <label >Last Name</label>
                <!---End of the Name section--->

                <h2>Email</h2>
                <input type="email" name='email' placeholder="name@gmail.com">
                <br>
                <label>Email</label>
                <!---End of email section--->

                <h2>Address</h2>
                <input type="text" name='street'><br>
                <label>Street</label><br><br>
                
                <input type="text" name='city'><br>
                <label>City</label><br><br>

                <?php foreach($statesArray as $x) : ?>
                    <input type="hidden" name='statesArray[]' value='<?php echo htmlspecialchars($x); ?>'>
                <?php endforeach; ?>
                
                <select name="state" id="state">
                    <?php foreach($statesArray as $stateID => $x) : ?>
                    <option value="<?php echo $stateID; ?>" ><?php echo htmlspecialchars($x); ?></option>
                    <?php endforeach; ?>
                </select><br>
                <label>State</label>
                <!---End of Address section--->

                <h2>Phone Number</h2>
                <input type="text" name='phone'><br>
                <label>Phone</label>
                <!---End of Phone section--->

                <h2>Membership Type</h2>
                <input type="radio" name='membership' value='1 Year Membership'>
                <label>1 Year Membership $100.00</label><br><br>
                
                <input type="radio" name='membership' value='5 Year Membership'>
                <label>5 Year Membership $200.00</label><br>

                <input type="submit" value='Apply for Membership'>


            </form>


            



        </main>
    </body>
</html>