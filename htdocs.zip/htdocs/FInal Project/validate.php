<?php  


    //Has code that will validate the input from the user
    function validatePhone($phone){
        if($phone == null){
            die("The phone number field is empty");
        
        }elseif(strlen($phone) != 10){
            die("Phone number must be 10 digits.");
        
        }elseif(!is_numeric($phone)){
            die("Only put numbers in the phone field.");
        }
    }

   function validateEmail($email){
        if($email === FALSE){
            die("Must enter a valid email.");

        }elseif($email == null){
            die("The email field is empty.");

        }
        
   }

   function notNull(...$inputs){
        foreach($inputs as $input){
            if($input == Null){
                die("An input field was left blank.");
                
            }
        }
   }

   