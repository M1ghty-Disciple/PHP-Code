<?php

include "validate.php";

//variables
$first = filter_input(INPUT_POST, 'first');
$last = filter_input(INPUT_POST, 'last');
$email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
$street = filter_input(INPUT_POST, 'street');
$city = filter_input(INPUT_POST, 'city');
$statesArray = filter_input(INPUT_POST, 'statesArray',FILTER_DEFAULT, FILTER_REQUIRE_ARRAY);
$stateIndex = filter_input(INPUT_POST, "state", FILTER_VALIDATE_INT);
$phone = filter_input(INPUT_POST,'phone');
$membership = filter_input(INPUT_POST, 'membership');





//create the code that will insert into the database

try{
    validatePhone($phone);
    validateEmail($email);
    notNull($first, $last, $street, $city, $statesArray[$stateIndex], $membership);
    
    
    require_once "database.php";
    $query = "INSERT INTO applicants(fName, lName, email, phone, address, city, state, membership_type)
            VALUES(?, ?, ?, ?, ?, ?, ?, ?);";

    $stmt = $pdo->prepare($query);

    $stmt->execute([$first, $last, $email, $phone, $street, $city, $statesArray[$stateIndex], $membership ]);


    //closes the connection
    $pdo = null;
    $stmt = null;

    die();


}catch(PDOException $e){
    die("Query failed: " . $e->getMessage());


}

