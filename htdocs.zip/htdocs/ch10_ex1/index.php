<?php
// set default value
$message = '';

// get value from POST array
$action = filter_input(INPUT_POST, 'action');
if ($action === NULL) {
    $action =  'start_app';
}

// process
switch ($action) {
    case 'start_app':

        // set default invoice date 1 month prior to current date
        $default_date = new DateTime();
        $default_date->sub(new DateInterval('P1M'));
        $invoice_date_s = $default_date->format('n/j/Y');

        // set default due date 2 months after current date
        $default_date->add(new DateInterval('P2M'));
        $due_date_s = $default_date->format('n/j/Y');

        $message = 'Enter two dates and click on the Submit button.';
        break;

    case 'process_data':
        $invoice_date_s = filter_input(INPUT_POST, 'invoice_date');
        $due_date_s = filter_input(INPUT_POST, 'due_date');

        // make sure the user enters both dates
        if ($invoice_date_s === NULL || $due_date_s === NULL) {
            $message = "Enter a valid date for the invoice and the due date.";
        } else {
            try {
                // convert date strings to DateTime objects
                $invoice_date = DateTime::createFromFormat('n/j/Y', $invoice_date_s);
                $due_date = DateTime::createFromFormat('n/j/Y', $due_date_s);

                // make sure the dates are valid
                if (!$invoice_date || !$due_date) {
                    throw new Exception();
                }

                // make sure the due date is after the invoice date
                if ($due_date < $invoice_date) {
                    $message = "The due date must be later than the invoice date.";
                } else {
                    // format both dates
                    $invoice_date_f = $invoice_date->format('n/j/Y');
                    $due_date_f = $due_date->format('n/j/Y');

                    // get the current date and time and format it
                    $current_date = new DateTime();
                    $current_date_f = $current_date->format('n/j/Y');
                    $current_time_f = $current_date->format('h:i:sa');

                    // get the amount of time between the current date and the due date
                    $dateDiff = $current_date->diff($due_date);
                    
                    // format the due date message
                    $due_date_message = "The payment is due in " . $dateDiff->days . " days.";
                }
            } catch (Exception $e) {
                $message = "Enter a valid format for the invoice and due dates.";
            }
        }
        break;
}

include 'date_tester.php';
?>